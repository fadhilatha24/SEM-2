#ifndef HIGHLIGHTAREA_H
#define HIGHLIGHTAREA_H

#include <graphics.h>

class HighlightArea {
private:
    int cx, cy;
    int innerR, outerR;
    float startAngle;
    float sizeDeg; // angular width

public:
    HighlightArea(int x, int y, int innerRadius, int outerRadius);

    void randomize();
    bool contains(float angleDeg) const;
    void draw(int color) const;

    float getStartAngle() const;
    float getSizeDeg() const;
};

#endif
