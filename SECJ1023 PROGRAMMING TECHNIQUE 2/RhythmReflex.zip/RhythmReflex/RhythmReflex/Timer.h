#ifndef TIMER_H
#define TIMER_H

#include <ctime>

// Simple wall-clock timer (seconds).
// Uses time(NULL) so it continues even if the game loop is frozen/delayed.
class Timer {
private:
    time_t startTime;
    int durationSeconds;
    bool running;

public:
    Timer(int seconds = 30)
        : startTime(0), durationSeconds(seconds), running(false) {}

    void start() {
        startTime = time(NULL);
        running = true;
    }

    void reset(int seconds) {
        durationSeconds = seconds;
        start();
    }

    bool isRunning() const { return running; }

    int getElapsed() const {
        if (!running) return 0;
        return (int)difftime(time(NULL), startTime);
    }

    int timeLeft() const {
        if (!running) return durationSeconds;
        int remaining = durationSeconds - getElapsed();
        return (remaining > 0) ? remaining : 0;
    }

    bool isTimeUp() const { return timeLeft() <= 0; }

    int getDuration() const { return durationSeconds; }
};

#endif
