#ifndef SCOREBOARD_H
#define SCOREBOARD_H

#include <graphics.h>
#include <cstdio>
#include <cstdlib>

class Scoreboard {
private:
    // Score
    int score;

    // Combo system (+2 ? +4 ? +6)
    int comboAdd;
    static const int MAX_COMBO = 6;

    // Encouragement message
    const char* currentMsg;
    int msgFrames;

    // Popup for "+2/+4/+6"
    int lastAdd;
    int popupFrames;

    // Accuracy tracking
    int attempts;
    int hits;

    // Utility to pick random encouragement strings
    static const char* randomFrom(const char* const* arr, int n);

public:
    // Constructor
    Scoreboard();

    // Reset everything
    void reset();

    // Accuracy tracking
    void recordAttempt(bool success);
    int getAttempts() const;
    int getHits() const;
    float getAccuracy() const;

    // Gameplay actions
    void successfulHit();
    void missedHit();

    // Getters
    int getScore() const;
    int getComboAdd() const;

    // Frame update
    void tickMessage();

    // Drawing
    void drawCenter(int cx, int cy) const;
    void drawAddPopup(int cx, int cy, int outerR) const;
};

#endif
