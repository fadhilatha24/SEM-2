#ifndef POINTER_H
#define POINTER_H

#include <graphics.h>
#include "HighlightArea.h"

class Pointer {
private:
    float angleDeg;
    float speedDeg;
    bool frozen;
    int cx, cy;
    int radius; // path radius
    int tipR;   // pointer circle size
    int color;

public:
    Pointer(int centerX, int centerY, int pathRadius, int pointerRadius, int c);

    float randomizeSpeed(float minSpeed, float maxSpeed);
    void rotate();

    void freeze();
    void unfreeze();
    bool isFrozen() const;

    float getAngle() const;
    bool isInside(const HighlightArea& zone) const;

    void draw() const;

    void setSpeed(float s);
    float getSpeed() const;
};

#endif
