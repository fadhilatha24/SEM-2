#include "Pointer.h"
#include <cmath>
#include <cstdlib>

Pointer::Pointer(int centerX, int centerY, int pathRadius, int pointerRadius, int c)
    : angleDeg(0.0f),
      speedDeg(8.0f),
      frozen(false),
      cx(centerX),
      cy(centerY),
      radius(pathRadius),
      tipR(pointerRadius),
      color(c) {
}

float Pointer::randomizeSpeed(float minSpeed, float maxSpeed) {
    speedDeg = minSpeed +
               (float)rand() / (float)RAND_MAX * (maxSpeed - minSpeed);
    return speedDeg;
}

void Pointer::rotate() {
    if (frozen) return;

    angleDeg += speedDeg;
    if (angleDeg >= 360.0f) angleDeg -= 360.0f;
    if (angleDeg < 0.0f) angleDeg += 360.0f;
}

void Pointer::freeze() {
    frozen = true;
}

void Pointer::unfreeze() {
    frozen = false;
}

bool Pointer::isFrozen() const {
    return frozen;
}

float Pointer::getAngle() const {
    return angleDeg;
}

bool Pointer::isInside(const HighlightArea& zone) const {
    return zone.contains(angleDeg);
}

void Pointer::draw() const {
    float rad = angleDeg * 3.14159265f / 180.0f;
    int px = cx + (int)(radius * cos(rad));
    int py = cy - (int)(radius * sin(rad));

    setcolor(color);
    setfillstyle(SOLID_FILL, color);
    fillellipse(px, py, tipR, tipR);
}

void Pointer::setSpeed(float s) {
    speedDeg = s;
}

float Pointer::getSpeed() const {
    return speedDeg;
}
