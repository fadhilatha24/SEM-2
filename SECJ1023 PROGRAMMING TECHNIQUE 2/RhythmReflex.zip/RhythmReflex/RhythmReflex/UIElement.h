#ifndef SCOREBOARD_H
#define SCOREBOARD_H

#include <graphics.h>
#include <cstdio>
#include <cstdlib>

class Scoreboard {
private:
    // [Aqmal]
    int score;

    // [New]
    // +2 -> +4 -> +6, capped at +6
    int comboAdd;
    const int MAX_COMBO = 6;

    // [Fadhil]
    const char* currentMsg;

    // [New] Frame-based display duration for encouragement text
    int msgFrames;

    // [New] Mini popup beside donut for "+2/+4/+6"
    int lastAdd;
    int popupFrames;

    // [New] Utility to pick random encouragement strings
    static const char* randomFrom(const char* const* arr, int n) {
        return arr[rand() % n];
    }

public:
    // [Aqmal][Altered] Initialize popup variables
    Scoreboard()
        : score(0), comboAdd(2), currentMsg(nullptr), msgFrames(0),
          lastAdd(0), popupFrames(0) {}

    // [Aqmal][Modified] Reset exists, expanded to reset combo + popup
    void reset() {
        score = 0;
        comboAdd = 2;
        currentMsg = nullptr;
        msgFrames = 0;

        // [New] reset popup state
        lastAdd = 0;
        popupFrames = 0;
    }

    // [Fadhil] implements required scoring ramp + popup
    void successfulHit() {
        // [New] capture current gain before comboAdd increments
        lastAdd = comboAdd;
        popupFrames = 45; // ~0.75s @ ~60fps

        // [New] apply score gain
        score += comboAdd;

        // [New] combo ramp: +2 -> +4 -> +6
        if (comboAdd < MAX_COMBO) comboAdd += 2;

        // [New] rotating encouragement messages
        static const char* const hitMsgs[] = {
            "Amazing!", "Keep it up!", "WOW!", "Nice!", "Great!"
        };
        currentMsg = randomFrom(hitMsgs, 5);
        msgFrames = 60;
    }

    // [Fadhil]
    // [New] resets combo as per requirements
    void missedHit() {
        // [New] reset combo gain to +2
        comboAdd = 2;

        // [New] hide popup instantly on miss
        lastAdd = 0;
        popupFrames = 0;

        static const char* const missMsgs[] = {
            "Miss!", "Oops!", "Try again!", "Almost!"
        };
        currentMsg = randomFrom(missMsgs, 4);
        msgFrames = 60;
    }

    // [Aqmal]
    int getScore() const { return score; }
    int getComboAdd() const { return comboAdd; }

    // [New] update both encouragement + popup timers per frame
    void tickMessage() {
        if (msgFrames > 0) --msgFrames;
        if (msgFrames == 0) currentMsg = nullptr;

        if (popupFrames > 0) --popupFrames;
    }

    // [Aqmal][Modified] Now self-contained drawing: center score + encouragement text
    void drawCenter(int cx, int cy) const {
        setcolor(BLACK);
        settextstyle(DEFAULT_FONT, HORIZ_DIR, 6);

        char s[16];
        sprintf(s, "%d", score);
        int w = textwidth(s);
        int h = textheight(s);
        outtextxy(cx - w / 2, cy - h / 2 - 10, s);

        // [Fadhil]
        if (currentMsg != nullptr) {
            settextstyle(DEFAULT_FONT, HORIZ_DIR, 2);
            int mw = textwidth((char*)currentMsg);
            outtextxy(cx - mw / 2, cy + 40, (char*)currentMsg);
        }
    }

    // [New] mini popup beside donut showing last gain (+2/+4/+6)
    void drawAddPopup(int cx, int cy, int outerR) const {
        if (popupFrames <= 0 || lastAdd <= 0) return;

        char p[8];
        sprintf(p, "+%d", lastAdd);

        // [New] Position: right side of donut
        int x = cx + outerR + 25;
        int y = cy - 20;

        // [New] popup box to make it readable
        int pad = 6;
        int w = textwidth(p);
        int h = textheight(p);

        setfillstyle(SOLID_FILL, WHITE);
        setcolor(BLACK);
        bar(x - pad, y - pad, x + w + pad, y + h + pad);
        rectangle(x - pad, y - pad, x + w + pad, y + h + pad);

        settextstyle(DEFAULT_FONT, HORIZ_DIR, 2);
        setcolor(BLACK);
        outtextxy(x, y, p);
    }

    // [Aqmal][Modified] Timer display; set to BLACK for white background
    void drawTimerTopRight(int timeLeft) const {
        char t[32];
        sprintf(t, "Time Left: %ds", timeLeft);

        settextstyle(DEFAULT_FONT, HORIZ_DIR, 2);
        setcolor(BLACK);

        int padding = 10;
        int x = getmaxx() - textwidth(t) - padding;
        int y = padding;
        outtextxy(x, y, t);
    }

    // [Aqmal][Modified] Instruction display; set to BLACK for white background
    void drawInstructionBottom() const {
        const char* inst = "Hit [SPACE] when the pointer is in the zone";
        settextstyle(DEFAULT_FONT, HORIZ_DIR, 2);
        setcolor(BLACK);

        int x = (getmaxx() - textwidth((char*)inst)) / 2;
        int y = getmaxy() - 40;
        outtextxy(x, y, (char*)inst);
    }
};

#endif
