#include "UIHelper.h"

namespace UILogic {

    void drawTitleTopLeft(const char* text) {
        settextstyle(DEFAULT_FONT, HORIZ_DIR, 2);
        setcolor(BLUE);
        outtextxy(10, 10, (char*)text);
    }

    void makeTimerText(char* out, int outSize, int timeLeft) {
        snprintf(out, outSize, "Time Left: %ds", timeLeft);
    }

    void drawTextRight(int screenW, int y, const char* text,
                    int color, int fontSize, int padding) {
        settextstyle(DEFAULT_FONT, HORIZ_DIR, fontSize);
        setcolor(color);
        int x = screenW - textwidth((char*)text) - padding;
        outtextxy(x, y, (char*)text);
    }

    void drawTextCentered(int cx, int y, const char* text,
                        int color, int fontSize) {
        settextstyle(DEFAULT_FONT, HORIZ_DIR, fontSize);
        setcolor(color);
        int x = cx - textwidth((char*)text) / 2;
        outtextxy(x, y, (char*)text);
    }

    void drawLargeTitleImage(int cx, int cy) {
        int w = 340, h = 150;  
        int left = cx - w / 2;
        int top = cy - h / 2;
        int right = cx + w / 2;
        int bottom = cy + h / 2;

        readimagefile("title.bmp", left, top, right, bottom);
    }

    void drawSmallTitleImage(int cx, int cy) {
        int w = 190, h = 80;  
        int left = 10;
        int top = 10; 
        int right = left + w;
        int bottom = top + h;

        readimagefile("title.bmp", left, top, right, bottom);
    }

} 


