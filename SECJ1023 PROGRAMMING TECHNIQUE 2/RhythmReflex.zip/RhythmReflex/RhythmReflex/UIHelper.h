#ifndef UIHELPER_H
#define UIHELPER_H

#include <graphics.h>
#include <cstdio>

namespace UIHelper {

    // title at the top-left corner
    void drawTitleTopLeft(const char* text);

    // format and display the timer text
    void makeTimerText(char* out, int outSize, int timeLeft);

    // draw text aligned to the right
    void drawTextRight(int screenW, int y, const char* text,
                    int color = BLACK, int fontSize = 2, int padding = 10);

    // draw text centered horizontally
    void drawTextCentered(int cx, int y, const char* text,
                        int color = BLACK, int fontSize = 2);

    // large title image at the center
    void drawLargeTitleImage(int cx, int cy);

    // small title image at the top-left corner
    void drawSmallTitleImage(int cx, int cy);

} 

#endif
