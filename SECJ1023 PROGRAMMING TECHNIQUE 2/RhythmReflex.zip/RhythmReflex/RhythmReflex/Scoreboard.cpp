#include "Scoreboard.h"

// ---------- Utility ----------
const char* Scoreboard::randomFrom(const char* const* arr, int n) {
    return arr[rand() % n];
}

// ---------- Constructor ----------
Scoreboard::Scoreboard()
    : score(0),
      comboAdd(2),
      currentMsg(nullptr),
      msgFrames(0),
      lastAdd(0),
      popupFrames(0),
      attempts(0),
      hits(0) {}

// ---------- Reset ----------
void Scoreboard::reset() {
    score = 0;
    comboAdd = 2;
    currentMsg = nullptr;
    msgFrames = 0;
    lastAdd = 0;
    popupFrames = 0;
    attempts = 0;
    hits = 0;
}

// ---------- Accuracy ----------
void Scoreboard::recordAttempt(bool success) {
    attempts++;
    if (success) hits++;
}

int Scoreboard::getAttempts() const {
    return attempts;
}

int Scoreboard::getHits() const {
    return hits;
}

float Scoreboard::getAccuracy() const {
    if (attempts <= 0) return 0.0f;
    return (hits * 100.0f) / attempts;
}

// ---------- Gameplay ----------
void Scoreboard::successfulHit() {
    lastAdd = comboAdd;
    popupFrames = 45;

    score += comboAdd;

    if (comboAdd < MAX_COMBO)
        comboAdd += 2;

    static const char* const hitMsgs[] = {
        "Amazing!", "Keep it up!", "WOW!", "Nice!", "Great!"
    };

    currentMsg = randomFrom(hitMsgs, 5);
    msgFrames = 60;
}

void Scoreboard::missedHit() {
    comboAdd = 2;
    lastAdd = 0;
    popupFrames = 0;

    static const char* const missMsgs[] = {
        "Miss!", "Oops!", "Try again!", "Almost!"
    };

    currentMsg = randomFrom(missMsgs, 4);
    msgFrames = 60;
}

// ---------- Getters ----------
int Scoreboard::getScore() const {
    return score;
}

int Scoreboard::getComboAdd() const {
    return comboAdd;
}

// ---------- Frame Update ----------
void Scoreboard::tickMessage() {
    if (msgFrames > 0) --msgFrames;
    if (msgFrames == 0) currentMsg = nullptr;

    if (popupFrames > 0) --popupFrames;
}

// ---------- Drawing ----------
void Scoreboard::drawCenter(int cx, int cy) const {
    setcolor(BLACK);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 6);

    char s[16];
    sprintf(s, "%d", score);

    int w = textwidth(s);
    int h = textheight(s);

    outtextxy(cx - w / 2, cy - h / 2 - 10, s);

    if (currentMsg != nullptr) {
        settextstyle(DEFAULT_FONT, HORIZ_DIR, 2);
        int mw = textwidth((char*)currentMsg);
        outtextxy(cx - mw / 2, cy + 40, (char*)currentMsg);
    }
}

void Scoreboard::drawAddPopup(int cx, int cy, int outerR) const {
    if (popupFrames <= 0 || lastAdd <= 0) return;

    char p[8];
    sprintf(p, "+%d", lastAdd);

    int x = cx + outerR + 25;
    int y = cy - 20;

    int pad = 6;
    int w = textwidth(p);
    int h = textheight(p);

    setfillstyle(SOLID_FILL, WHITE);
    setcolor(BLACK);
    bar(x - pad, y - pad, x + w + pad, y + h + pad);
    rectangle(x - pad, y - pad, x + w + pad, y + h + pad);

    int popupColor = BLACK;
    if (lastAdd == 2) popupColor = COLOR(60, 60, 60);
    else if (lastAdd == 4) popupColor = COLOR(255, 180, 0);
    else if (lastAdd == 6) popupColor = COLOR(0, 170, 60);

    settextstyle(DEFAULT_FONT, HORIZ_DIR, 2);
    setcolor(popupColor);
    outtextxy(x, y, p);
}
