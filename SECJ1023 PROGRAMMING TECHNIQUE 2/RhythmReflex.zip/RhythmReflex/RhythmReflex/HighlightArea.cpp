#include "HighlightArea.h"
#include <cstdlib>   // rand()

HighlightArea::HighlightArea(int x, int y, int innerRadius, int outerRadius)
    : cx(x), cy(y), innerR(innerRadius), outerR(outerRadius),
      startAngle(0), sizeDeg(40) {
    randomize();
}

void HighlightArea::randomize() {
    startAngle = (float)(rand() % 360);
    // 15° to 70°
    sizeDeg = (float)(15 + rand() % 56);
}

bool HighlightArea::contains(float angleDeg) const {
    float endAngle = startAngle + sizeDeg;

    if (endAngle < 360.0f) {
        return angleDeg >= startAngle && angleDeg <= endAngle;
    }
    // wrap-around case
    return angleDeg >= startAngle || angleDeg <= (endAngle - 360.0f);
}

void HighlightArea::draw(int color) const {
    setcolor(color);
    // draw thick arc by sweeping radii across the donut thickness
    for (int r = innerR; r <= outerR; ++r) {
        arc(cx, cy, (int)startAngle, (int)(startAngle + sizeDeg), r);
    }
}

float HighlightArea::getStartAngle() const {
    return startAngle;
}

float HighlightArea::getSizeDeg() const {
    return sizeDeg;
}
